<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dasbor2 extends CI_Controller {
	
	// Index login
	public function index() {
		$data = array(	'isi'	=> 'dasbor_view');
		$this->load->view('layout/wrapper2',$data);
	}
	
	// Fungsi lain
	}