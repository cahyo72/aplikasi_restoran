<!doctype html>
<html>
   <head>
	<meta charset="utf-8">
<title>Kategori Create</title>
<link href="<?php echo base_url() ?>Majestic/images/welcome1.png" rel="shortcut icon">
<link href="<?php echo base_url() ?>Majestic/css/style.css" rel="stylesheet">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Majestic - Free Bootstrap Restaurant Website Template</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="<?php echo base_url() ?>Majestic/css/bootstrap.min.css" rel="stylesheet">

<link rel="<?php echo base_url() ?>Majestic/stylesheet" href="style.css" type="text/css">

<link rel="stylesheet" href="<?php echo base_url() ?>Majestic/css/font-awesome.min.css" type="text/css">

<link href='http://fonts.googleapis.com/css?family=Oxygen:400,300,700' rel='stylesheet' type='text/css'>

<link href='http://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,900,700,700italic,900italic' rel='stylesheet' type='text/css'>

<link href='http://fonts.googleapis.com/css?family=Niconne' rel='stylesheet' type='text/css'>
		<link href="<?php echo base_url('Majestic/css/bootstrap.min.css') ?>Majestic/css/style.css" rel="stylesheet">
        <style>
            body{
                padding: 15px;
            }
        </style>
		<link href="<?php echo base_url() ?>Majestic/css/style.css" rel="stylesheet">
	<!-- Start Nav -->
	<header class="headbar">
	  <div class="fullbg">

    <div class="row">
    <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-12">
    <nav class="navi navbar navbar-default" role="navigation"> 
       <div class="navbar-header">
       <button type="button" class="navbar-toggle collapsed navb" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        </div>
		   <div class="menubox collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav menu">
			<li><a href="<?php echo base_url('dasbor') ?>">Home</a></li>
            <li><a href="<?php echo base_url('Pemesanan/index3') ?>">Lihat Pesanan</a></li>
			<li><a href="<?php echo base_url('Menu') ?>">Lihat Menu</a></li>
			<li><a href="<?php echo base_url('User') ?>">Lihat User</a></li>
			<li><a href="<?php echo base_url('Transaksi') ?>">Lihat Transaksi</a></li>
			<li><a href="<?php echo base_url('Kategori') ?>">Lihat Kategori</a></li>
			<li><a href="<?php echo base_url('Admin') ?>">Lihat Admin</a></li>
			<li><a href="<?php echo base_url('dasbor') ?>" >Logout</a></li>
			</ul>
			</div>
    </nav>
	</div>
	</div>
	</div>
	</header>
    </head>
	
    <body>
	<div class="container-fluid upevent section-container">

  <div class="upevent-effect">

    <div class="row">

      <div class="col-md-8 col-md-offset-2 col-xs-12 uphead">

        <span class="header-text">Majestic Restaurant</span> </div>

      <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-12 upbox">

      <div class="col-md-12 col-sm-12 col-xs-12 special-note"> 
	  <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 forming">
		<form role="form">
		
		<div class="col-md-6 col-sm-6">
	
        <h2 style="margin-top:0px">Kategori <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Nama Makan <?php echo form_error('nama_makan') ?></label>
            <input type="text" class="form-control" name="nama_makan" id="nama_makan" placeholder="Nama Makan" value="<?php echo $nama_makan; ?>" />
        </div>
	    <input type="hidden" name="id_kategori" value="<?php echo $id_kategori; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('kategori') ?>" class="btn btn-default">Cancel</a>
	</div>
	</form>
    </body>
</html>