<!doctype html>
<html>
    <head>
	<meta charset="utf-8">
<title>Kategori List</title>
<link href="<?php echo base_url() ?>Majestic/images/welcome1.png" rel="shortcut icon">
<link href="<?php echo base_url() ?>Majestic/css/style.css" rel="stylesheet">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Majestic - Free Bootstrap Restaurant Website Template</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="<?php echo base_url() ?>Majestic/css/bootstrap.min.css" rel="stylesheet">

<link rel="<?php echo base_url() ?>Majestic/stylesheet" href="style.css" type="text/css">

<link rel="stylesheet" href="<?php echo base_url() ?>Majestic/css/font-awesome.min.css" type="text/css">

<link href='http://fonts.googleapis.com/css?family=Oxygen:400,300,700' rel='stylesheet' type='text/css'>

<link href='http://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,900,700,700italic,900italic' rel='stylesheet' type='text/css'>

<link href='http://fonts.googleapis.com/css?family=Niconne' rel='stylesheet' type='text/css'>
		<link href="<?php echo base_url('Majestic/css/bootstrap.min.css') ?>Majestic/css/style.css" rel="stylesheet">
        <style>
            body{
                padding: 15px;
            }
        </style>
		<link href="<?php echo base_url() ?>Majestic/css/style.css" rel="stylesheet">
	<!-- Start Nav -->
	<header class="headbar">
	  <div class="fullbg">

    <div class="row">
    <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-12">
    <nav class="navi navbar navbar-default" role="navigation"> 
       <div class="navbar-header">
       <button type="button" class="navbar-toggle collapsed navb" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        </div>
		   <div class="menubox collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav menu">
			<li><a href="<?php echo base_url('dasbor') ?>">Home</a></li>
            <li><a href="<?php echo base_url('Pemesanan/index3') ?>">Lihat Pesanan</a></li>
			<li><a href="<?php echo base_url('Menu') ?>">Lihat Menu</a></li>
			<li><a href="<?php echo base_url('User') ?>">Lihat User</a></li>
			<li><a href="<?php echo base_url('Transaksi') ?>">Lihat Transaksi</a></li>
			<li><a href="<?php echo base_url('Kategori') ?>">Lihat Kategori</a></li>
			<li><a href="<?php echo base_url('Admin') ?>">Lihat Admin</a></li>
			<li><a href="<?php echo base_url('dasbor') ?>" >Logout</a></li>
			</ul>
			</div>
    </nav>
	</div>
	</div>
	</div>
	</header>
    </head>

    <body>
   <div class="container-fluid upevent section-container">

  <div class="upevent-effect">

    <div class="row">

      <div class="col-md-8 col-md-offset-2 col-xs-12 uphead">

         </div>

      <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-12 upbox">

        <div class="col-md-12 col-sm-12 col-xs-12 special-note"> 	
        <div class="row" style="margin-bottom: 10px">

        <h2 style="margin-top:0px">Kategori List</h2>
        <div class="row" style="margin-bottom: 10px">
            <div class="col-md-4">

                <?php echo anchor(site_url('kategori/create'),'Create', 'class="btn btn-primary"'); ?>
            </div>
            <div class="col-md-4 text-center">
                <div style="margin-top: 8px" id="message">
                    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                </div>
            </div>
            <div class="col-md-1 text-right">
            </div>
            <div class="col-md-3 text-right">
                <form action="<?php echo site_url('kategori/index'); ?>" class="form-inline" method="get">
                    <div class="input-group">
                        <input type="text" class="form-control" name="q" value="<?php echo $q; ?>">
                        <span class="input-group-btn">
                            <?php 
                                if ($q <> '')
                                {
                                    ?>
                                    <a href="<?php echo site_url('kategori'); ?>" class="btn btn-default">Reset</a>
                                    <?php
                                }
                            ?>
                          <button class="btn btn-primary" type="submit">Search</button>
                        </span>
                    </div>
                </form>
            </div>
        </div>
        <table class="table table-bordered" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Nama Makan</th>
		<th>Action</th>
            </tr><?php
            foreach ($kategori_data as $kategori)
            {
                ?>
                <tr>
			<td width="80px"><?php echo ++$start ?></td>
			<td><?php echo $kategori->nama_makan ?></td>
			<td style="text-align:center" width="200px">
				<?php 
				echo anchor(site_url('kategori/read/'.$kategori->id_kategori),'Read'); 
				echo ' | '; 
				echo anchor(site_url('kategori/update/'.$kategori->id_kategori),'Update'); 
				echo ' | '; 
				echo anchor(site_url('kategori/delete/'.$kategori->id_kategori),'Delete','onclick="javasciprt: return confirm(\'Are You Sure ?\')"'); 
				?>
			</td>
		</tr>
                <?php
            }
            ?>
        </table>
        <div class="row">
            <div class="col-md-6">
                <a href="#" class="btn btn-primary">Total Record : <?php echo $total_rows ?></a>
				<a href="dasbor3" class="btn btn-primary">Home</a>
	    </div>
            <div class="col-md-6 text-right">
                <?php echo $pagination ?>
                 <footer class="footerinfo container-fluid">

  <div class="row">

    <div class="col-md-12 col-sm-12">

      <p>&copy; 2015 Designed By <a href="http://www.html5layouts.com">HTML5 Layouts</a> Using <a href="http://www.picjumbo.com">Picjumbo</a> Images. | <a href="http://vectortoons.com/">Get Vector Graphics</a></p>

    </div>

  </div>

</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 

<script src="js/bootstrap.min.js"></script>
 
 </div>
 </div>
 </div>
 </div>
 </div>
 </div>
 </div>

				</div>
        </div>
    </body>
</html>