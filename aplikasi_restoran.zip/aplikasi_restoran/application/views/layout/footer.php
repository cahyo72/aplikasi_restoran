</article>
    <!-- Start Footer -->
<footer class="footerinfo container-fluid">

  <div class="row">

    <div class="col-md-12 col-sm-12">

      <p>&copy; 2015 Designed By <a href="http://www.html5layouts.com">HTML5 Layouts</a> Using <a href="http://www.picjumbo.com">Picjumbo</a> Images. | <a href="http://vectortoons.com/">Get Vector Graphics</a></p>

    </div>

  </div>

</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 

<script src="js/bootstrap.min.js"></script>
 
</section>
</body>
</html>
