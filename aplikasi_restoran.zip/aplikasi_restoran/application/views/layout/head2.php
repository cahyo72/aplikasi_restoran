<?php
// Proteksi halaman

?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Home</title>
<link href="<?php echo base_url() ?>Majestic/images/welcome1.png" rel="shortcut icon">
<link href="<?php echo base_url() ?>Majestic/css/style.css" rel="stylesheet">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="<?php echo base_url() ?>Majestic/css/bootstrap.min.css" rel="stylesheet">

<link rel="<?php echo base_url() ?>Majestic/stylesheet" href="style.css" type="text/css">

<link rel="stylesheet" href="<?php echo base_url() ?>Majestic/css/font-awesome.min.css" type="text/css">

<link href='http://fonts.googleapis.com/css?family=Oxygen:400,300,700' rel='stylesheet' type='text/css'>

<link href='http://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,900,700,700italic,900italic' rel='stylesheet' type='text/css'>

<link href='http://fonts.googleapis.com/css?family=Niconne' rel='stylesheet' type='text/css'>

</head>

<body>
