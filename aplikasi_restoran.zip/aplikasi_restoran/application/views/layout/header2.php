<!-- Start Header -->
	<link href="<?php echo base_url() ?>Majestic/css/style.css" rel="stylesheet">
	<!-- Start Nav -->
	<header class="headbar">
	  <div class="fullbg">

    <div class="row">
    <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-12">
    <nav class="navi navbar navbar-default" role="navigation"> 
       <div class="navbar-header">
       <button type="button" class="navbar-toggle collapsed navb" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        </div>
		   <div class="menubox collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav menu">
        	        	<li><a href="<?php echo base_url('dasbor') ?>">Home</a></li>
            <li><a href="<?php echo base_url('dasbor/about') ?>">Buat Pesanan</a></li>
			<li><a href="<?php $q = ucfirst($this->session->userdata('username'));
			echo base_url('pemesanan/index2?q='.$q) ?>">Lihat Transaksi</a></li>
			<li><a href="<?php echo base_url('dasbor') ?>">Logout</a></li>
			</ul>
			</div>
    </nav>
	</div>
	</div>
	</div>
	</header>
    <!-- Start Article -->
    <article>