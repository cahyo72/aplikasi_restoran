<html>
<div class="container-fluid upevent section-container">

  <div class="upevent-effect">

    <div class="row">

      <div class="col-md-8 col-md-offset-2 col-xs-12 uphead">

        <span class="header-text">Majestic Restaurant</span> </div>

      <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-12 upbox">

        <div class="col-md-12 col-sm-12 col-xs-12 upimg"> <img src="Majestic/images/upcoming.jpg"/> </div>

        <div class="col-md-12 col-sm-12 col-xs-12 special-note"> 

          
          <p>Selamat datang Admin di website restoran cepat saji terbaik di Indonesia</p>

        </div>

      </div>

    

    </div>

  </div>

</div>
</html>