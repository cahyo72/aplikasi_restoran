<?php
// Panggil semua file layout
require_once('head2.php');
require_once('header.php');
require_once('konten.php');
require_once('footer.php');
?>