<?php
// Panggil semua file layout
require_once('head.php');
require_once('header2.php');
require_once('konten.php');
require_once('footer.php');