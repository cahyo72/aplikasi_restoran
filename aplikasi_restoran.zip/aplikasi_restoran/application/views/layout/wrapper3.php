<?php
// Panggil semua file layout
require_once('head3.php');
require_once('header3.php');
require_once('konten3.php');
require_once('footer.php');