<!doctype html>
<html>
    <head>
	<meta charset="utf-8">
<title>Pemesanan</title>
<link href="<?php echo base_url() ?>Majestic/images/welcome1.png" rel="shortcut icon">
<link href="<?php echo base_url() ?>Majestic/css/style.css" rel="stylesheet">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Majestic - Free Bootstrap Restaurant Website Template</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="<?php echo base_url() ?>Majestic/css/bootstrap.min.css" rel="stylesheet">

<link rel="<?php echo base_url() ?>Majestic/stylesheet" href="style.css" type="text/css">

<link rel="stylesheet" href="<?php echo base_url() ?>Majestic/css/font-awesome.min.css" type="text/css">

<link href='http://fonts.googleapis.com/css?family=Oxygen:400,300,700' rel='stylesheet' type='text/css'>

<link href='http://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,900,700,700italic,900italic' rel='stylesheet' type='text/css'>

<link href='http://fonts.googleapis.com/css?family=Niconne' rel='stylesheet' type='text/css'>
		<link href="<?php echo base_url('Majestic/css/bootstrap.min.css') ?>Majestic/css/style.css" rel="stylesheet">
        <style>
            body{
                padding: 15px;
            }
        </style>
		<link href="<?php echo base_url() ?>Majestic/css/style.css" rel="stylesheet">
	<!-- Start Nav -->
	<header class="headbar">
	  <div class="fullbg">

    <div class="row">
    <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-12">
    <nav class="navi navbar navbar-default" role="navigation"> 
       <div class="navbar-header">
       <button type="button" class="navbar-toggle collapsed navb" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

        </div>
		   <div class="menubox collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav menu">
        	        	<li><a href="<?php echo base_url('dasbor2') ?>">Home</a></li>
            <li><a href="<?php echo base_url('Pemesanan') ?>">Buat Pesanan</a></li>
			<li><a href="<?php $q = ucfirst($this->session->userdata('username'));
			echo base_url('pemesanan/index2?q='.$q) ?>">Lihat Transaksi</a></li>
			<li><a href="<?php echo base_url('dasbor') ?>">Logout</a></li>
			</ul>
			</div>
    </nav>
	</div>
	</div>
	</div>
	</header>
    </head>
    <body>
	
	<div class="container-fluid upevent section-container">

  <div class="upevent-effect">

    <div class="row">

      <div class="col-md-8 col-md-offset-2 col-xs-12 uphead">

        <span class="header-text">Majestic Restaurant</span> </div>

      <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-12 upbox">

        <div class="col-md-12 col-sm-12 col-xs-12 upimg"> <img src="Majestic/images/upcoming.jpg"/> </div>

        <div class="col-md-12 col-sm-12 col-xs-12 special-note"> 
		
		<?php echo validation_errors(); ?>
		<?php echo form_open('pemesanan/index'); ?>
	 <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 forming">
		<form role="form">
		
		<div class="col-md-6 col-sm-6">
	    <div class="form-group">
            <label for="varchar">Nama </label>
			<input type="text" class="form-control" name="nama" id="nama" placeholder="Nama" value="<?php echo ucfirst($this->session->userdata('username')); ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Jumlah </label>
            <input type="text" class="form-control" name="jumlah" id="jumlah" placeholder="Jumlah" value="<?php echo set_value('jumlah'); ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Cara Bayar <?php echo form_error('cara_bayar') ?></label></br>
            <?php
			echo "Cash On Delivery".form_radio('cara_bayar','Cash On Delivery',False)."</br>";
			echo "Transfer".form_radio('cara_bayar','Transfer',False)."</br>"; 
			echo set_value('cara_bayar'); ?>
        </div>
	    <div class="form-group">
            <label for="varchar">Menu Makan </label></br>
			
			
            <?php 
				foreach ($query->result_array() as $row)
				{
				$options[$row['nama_menu']]=$row['nama_menu'];
				}
			echo form_dropdown('nama_menu', $options, set_value('menu_makan'));?>
			
			
        </div>
	    <div class="form-group">
            <label for="varchar">Menu Tambah <?php echo form_error('menu_tambah') ?></label></br>
            <?php
			echo "Mayonaise".form_checkbox('menu_tambah','Mayonaise',False)."</br>";
			echo "Saos Tomat".form_checkbox('menu_tambah','Saos Tomat',False)."</br>";
			echo "Saos Cabe".form_checkbox('menu_tambah','Saos Cabe',False)."</br>";
			echo "Saos Telur".form_checkbox('menu_tambah','Telur',False)."</br>";
			echo "Acar".form_checkbox('menu_tambah','Acar',False)."</br>";
			echo set_value('menu_tambah'); ?>
        </div>
	</div>
	
	<div class="col-md-6 col-sm-6">
	    <div class="form-group">
            <label for="date">Tanggal</label>
            <input type="date" class="form-control" name="tanggal" id="tanggal" placeholder="Tanggal" value="<?php echo set_value('tanggal'); ?>" />
        </div>
	</div>
	
	<div class="col-md-6 col-sm-6">
	    <div class="form-group">
            <label for="varchar">Keterangan <?php echo form_error('keterangan') ?></label>
            <input type="text" class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan" value="<?php echo set_value('keterangan'); ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Alamat Lengkap <?php echo form_error('alamat_lengkap') ?></label>
            <input type="text" class="form-control" name="alamat_lengkap" id="alamat_lengkap" placeholder="Alamat Lengkap" value="<?php echo set_value('alamat_lengkap'); ?>" />
        </div>
	    <div class="form-group">
            <input type="hidden" class="form-control" name="status_pesan" id="status_pesan" placeholder="Status Pesan" value="Pesanan akan dikirim" />
        </div>
	</div>
	
	    <input type="hidden" name="id_pemesanan" value="<?php echo set_value('id_pemesanan'); ?>" /> 
	    
	<div class="text-center">
		<button type="submit" class="btn btn-primary"><?php echo set_value('submit') ?> Submit</button> 
	    <a href="<?php echo site_url('dasbor2') ?>" class="btn btn-default">Cancel</a>
	</div>
	</form>
	</div>

      </div>

    

    </div>

  </div>

</div>

<footer class="footerinfo container-fluid">

  <div class="row">

    <div class="col-md-12 col-sm-12">

      <p>&copy; 2015 Designed By <a href="http://www.html5layouts.com">HTML5 Layouts</a> Using <a href="http://www.picjumbo.com">Picjumbo</a> Images. | <a href="http://vectortoons.com/">Get Vector Graphics</a></p>

    </div>

  </div>

</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 

<script src="js/bootstrap.min.js"></script>
 
</body>
</html>