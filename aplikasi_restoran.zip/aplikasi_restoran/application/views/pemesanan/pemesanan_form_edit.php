<!doctype html>
<html>
    <head>
       
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
		<?php echo validation_errors(); ?>
		<?php echo form_open('pemesanan/index'); ?>
		
	    <div class="form-group">
            <label for="varchar">Nama </label>
			<input type="text" class="form-control" name="nama" id="nama" placeholder="Nama" value="<?php echo set_value('nama'); ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Jumlah </label>
            <input type="text" class="form-control" name="jumlah" id="jumlah" placeholder="Jumlah" value="<?php echo set_value('jumlah'); ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Cara Bayar <?php echo form_error('cara_bayar') ?></label></br>
            <?php
			echo "Cash On Delivery".form_radio('cara_bayar','Cash On Delivery',False)."</br>";
			echo "Transfer".form_radio('cara_bayar','Transfer',False)."</br>"; 
			echo set_value('cara_bayar'); ?>
        </div>
	    <div class="form-group">
            <label for="varchar">Menu Makan </label></br>
            <?php foreach ($query->result_array() as $row)
				{
				$options[$row['nama_menu']]=$row['nama_menu'];
				}
			echo form_dropdown('nama_menu', $options, set_value('menu_makan'));?>
        </div>
	    <div class="form-group">
            <label for="varchar">Menu Tambah <?php echo form_error('menu_tambah') ?></label></br>
            <?php
			echo "Mayonaise".form_checkbox('menu_tambah','Mayonaise',False)."</br>";
			echo "Saos Tomat".form_checkbox('menu_tambah','Saos Tomat',False)."</br>";
			echo "Saos Cabe".form_checkbox('menu_tambah','Saos Cabe',False)."</br>";
			echo "Saos Telur".form_checkbox('menu_tambah','Telur',False)."</br>";
			echo "Acar".form_checkbox('menu_tambah','Acar',False)."</br>";
			echo set_value('menu_tambah'); ?>
        </div>
	    <div class="form-group">
            <label for="date">Tanggal <?php echo form_error('tanggal') ?></label>
            <input type="date" class="form-control" name="tanggal" id="tanggal" placeholder="Tanggal" value="<?php echo set_value('tanggal'); ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Keterangan <?php echo form_error('keterangan') ?></label>
            <input type="text" class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan" value="<?php echo set_value('keterangan'); ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Alamat Lengkap <?php echo form_error('alamat_lengkap') ?></label>
            <input type="text" class="form-control" name="alamat_lengkap" id="alamat_lengkap" placeholder="Alamat Lengkap" value="<?php echo set_value('alamat_lengkap'); ?>" />
        </div>
	    <div class="form-group">
            <input type="hidden" class="form-control" name="status_pesan" id="status_pesan" placeholder="Status Pesan" value="Pesanan akan dikirim" />
        </div>
	    <input type="hidden" name="id_pemesanan" value="<?php echo set_value('id_pemesanan'); ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo set_value('submit') ?> Submit</button> 
	    <a href="<?php echo site_url('dasbor2') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>