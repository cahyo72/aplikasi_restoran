<!doctype html>
<html>
    <head>
        <title>Halaman Detail Pemesanan</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Pemesanan Read</h2>
        <table class="table">
	    <tr><td>Nama</td><td><?php echo $nama; ?></td></tr>
	    <tr><td>Jumlah</td><td><?php echo $jumlah; ?></td></tr>
	    <tr><td>Cara Bayar</td><td><?php echo $cara_bayar; ?></td></tr>
	    <tr><td>Menu Makan</td><td><?php echo $menu_makan; ?></td></tr>
	    <tr><td>Menu Tambah</td><td><?php echo $menu_tambah; ?></td></tr>
	    <tr><td>Tanggal</td><td><?php echo $tanggal; ?></td></tr>
	    <tr><td>Keterangan</td><td><?php echo $keterangan; ?></td></tr>
	    <tr><td>Alamat Lengkap</td><td><?php echo $alamat_lengkap; ?></td></tr>
	    <tr><td>Status Pesan</td><td><?php echo $status_pesan; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('dasbor3') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>